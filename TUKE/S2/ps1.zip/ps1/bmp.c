#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include "bmp.h"

char* reverse(const char* text) {
    if (!text) return NULL;
    size_t length = strlen(text);
    char* reversed = (char*)malloc((length + 1) * sizeof(char));
    if (reversed == NULL) {
        return NULL;
    }
    const char* original_ptr = text;
    char* reversed_ptr = reversed + length;
    *reversed_ptr = '\0'; 
    while (*original_ptr != '\0') {
        *(--reversed_ptr) = *original_ptr++;
    }

    return reversed;
}

char* vigenere_encrypt(const char* key, const char* text) {
    if (!key || !text) return NULL;
    for (int i = 0; key[i] != '\0'; i++) {
        if (!isalpha(key[i]))
            return NULL;
    }

    for (int i = 0; text[i] != '\0'; i++) {
        if (!isalpha(text[i]))
            return NULL;
    }
    int key_len = strlen(key);
    int text_len = strlen(text);
    char* encrypted_text = (char*)malloc((text_len + 1) * sizeof(char));
    if (encrypted_text == NULL) {
        return NULL; // Unable to allocate memory
    }

    for (int i = 0, j = 0; i < text_len; i++) {
        char current_char = text[i];
        if (isalpha(current_char)) {
            char key_char = toupper(key[j % key_len]);
            int shift = key_char - 'A';
            if (islower(current_char))
                encrypted_text[i] = ((current_char - 'a' + shift) % 26) + 'A';
            else
                encrypted_text[i] = ((current_char - 'A' + shift) % 26) + 'A';
            j++;
        } else {
            encrypted_text[i] = current_char;
        }
    }
    encrypted_text[text_len] = '\0';
    return encrypted_text;
}

char* vigenere_decrypt(const char* key, const char* text) {
    if (!key || !text) return NULL;
    for (int i = 0; key[i] != '\0'; i++) {
        if (!isalpha(key[i]))
            return NULL;
    }

    for (int i = 0; text[i] != '\0'; i++) {
        if (!isalpha(text[i]))
            return NULL;
    }
    int key_len = strlen(key);
    int text_len = strlen(text);
    char* decrypted_text = (char*)malloc((text_len + 1) * sizeof(char));
    if (decrypted_text == NULL) {
        return NULL; // Unable to allocate memory
    }

    for (int i = 0, j = 0; i < text_len; i++) {
        char current_char = text[i];
        if (isalpha(current_char)) {
            char key_char = toupper(key[j % key_len]);
            int shift = key_char - 'A';
            if (islower(current_char))
                decrypted_text[i] = ((current_char - 'a' - shift + 26) % 26) + 'A';
            else
                decrypted_text[i] = ((current_char - 'A' - shift + 26) % 26) + 'A';
            j++;
        } else {
            decrypted_text[i] = current_char;
        }
    }
    decrypted_text[text_len] = '\0';
    return decrypted_text;
}


void encode_string(const char string[], bool bytes[strlen(string)+1][8]) {
    char string_element;
    int letter_ascii;
    for(int elm = 0; elm < strlen(string); elm++) {
        string_element = string[elm];
        letter_ascii = string_element;
        for(int div = 7; div >= 0; div--) {
            bytes[elm][div] = letter_ascii % 2;
            letter_ascii /= 2;
        }
    }
    for(int i = 0; i < 8; i++) {
        bytes[strlen(string)][i] = 0;
    }
}

unsigned char* bit_encrypt(const char* text) {
    if (!text) return NULL;
    // Check if the key contains only alphabetic characters
    for (int i = 0; text[i] != '\0'; i++) {
        if (!isalpha(text[i]))
            return NULL;
    }
    if (text == NULL) return NULL;
    int len = strlen(text);
    bool bytes[len+1][8];
    encode_string(text, bytes);

    // Encryption steps
	// swap
    for(int rows = 0; rows < len; rows++) {
        bool temp = bytes[rows][0];
        bytes[rows][0] = bytes[rows][1];
        bytes[rows][1] = temp;
        temp = bytes[rows][2];
        bytes[rows][2] = bytes[rows][3];
        bytes[rows][3] = temp;
    }
    //XOR
    for(int rows = 0; rows < len; rows++) {
        for(int i = 4; i < 8; i++) {
            bytes[rows][i] = bytes[rows][i] ^ bytes[rows][i - 4];
        }
    }

    // Convert binary to decimal
    unsigned char* encrypted = (unsigned char*)malloc(len * sizeof(unsigned char));
    for(int row = 0; row < len; row++) {
        unsigned char decimal = 0;
        for(int bit = 0; bit < 8; bit++) {
            decimal = (decimal << 1) | bytes[row][bit];
        }
        encrypted[row] = decimal;
    }

    return encrypted; 
}

char* bit_decrypt(const unsigned char* text) {
    if (!text) return NULL;
    // Check if the key contains only alphabetic characters
    // for (int i = 0; text[i] != '\0'; i++) {
    //     if (!isalpha(text[i]))
    //         return NULL;
    // }
    int len = strlen((const char*)text);
    char* decrypted = (char*)malloc(len+1);
    
    if (text == NULL) return NULL;
    else{
        for (int index = 0; index < len; index++) {
            int byte[8];
            int num = text[index];

            // Decimal to binary
            for (int i = 7; i >= 0; i--) {
                byte[i] = num % 2;
                num /= 2;
            }

            // XOR operation
            for (int i = 0; i < 4; i++) {
                byte[i + 4] = byte[i] ^ byte[i + 4];
            }


            //swap
            bool temp = byte[0];
            byte[0] = byte[1];
            byte[1] = temp;
            temp = byte[2];
            byte[2] = byte[3];
            byte[3] = temp;

            // Binary to decimal
            int decimal = 0;
            for (int i = 0; i < 8; i++) {
                decimal += byte[i] * pow(2, 7 - i);
            }

            // Result to output
            decrypted[index] = decimal;
        }
    }
    decrypted[len-2] = '\0';
    return decrypted;
}


unsigned char* bmp_encrypt(const char* key, const char* text) {
    char* rev_str = reverse(text);
    char* vig_str_enc = vigenere_encrypt(key, rev_str);
    unsigned char* bit_str_enc = bit_encrypt(vig_str_enc);
    free(rev_str); // Free the reversed string
    free(vig_str_enc); // Free the Vigenere-encrypted string
    return bit_str_enc;
}

char* bmp_decrypt(const char* key, const unsigned char* text) {
    char* bit_str_enc = bit_decrypt(text);
    char* vig_str_enc = vigenere_decrypt(key, bit_str_enc);
    char* rev_str = reverse(vig_str_enc);
    free(bit_str_enc); // Free the bit-decrypted string
    free(vig_str_enc); // Free the Vigenere-decrypted string
    return rev_str;
}
// int main() {
//     // char* encrypted = vigenere_encrypt("CoMPuTeR", "Hello world!");
//     // printf("%s\n", encrypted);  // "JSXAI PSINR!"
//     // free(encrypted);
//     const char* text = "!DLROW ,OLLEH";
//     printf("Original: %s\n", text);
//     printf("Reversed and Uppercase: %s\n", reverse(text));
//     return 0;
// }
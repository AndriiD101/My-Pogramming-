#include <stdio.h>
#include <stdlib.h>

typedef struct {
    // Define the structure of your BMP header here
    unsigned int size;
    unsigned int width;
    unsigned int height;
    // ... other header items
} bmp_header;

typedef struct {
    // Define the structure of your BMP data here
    unsigned char red;
    unsigned char green;
    unsigned char blue;
} pixel;

typedef struct {
    bmp_header header;
    pixel* data;
} bmp_image;

bmp_header* read_bmp_header(FILE* stream) {
    if (stream == NULL) {
        return NULL;
    }

    bmp_header* header = malloc(sizeof(bmp_header));
    // Read the BMP header from the stream
    fread(header, sizeof(bmp_header), 1, stream);
    // Check if the type is 'BM'
    if (header->type != 'BM') {
        free(header);
        return NULL;
    }

    return header;
}

pixel* read_data(FILE* stream, bmp_header* header) {
    if (stream == NULL || header == NULL) {
        return NULL;
    }

    pixel* data = malloc(header->width * header->height * sizeof(pixel));
    // Read the BMP data from the stream
    fread(data, sizeof(pixel), header->width * header->height, stream);

    return data;
}

bmp_image* read_bmp(FILE* stream) {
    if (stream == NULL) {
        fprintf(stderr, "Error: Stream is NULL.\n");
        return NULL;
    }

    bmp_header* header = read_bmp_header(stream);
    if (header == NULL) {
        fprintf(stderr, "Error: This is not a BMP file.\n");
        return NULL;
    }

    pixel* data = read_data(stream, header);
    if (data == NULL) {
        fprintf(stderr, "Error: Corrupted BMP file.\n");
        return NULL;
    }

    bmp_image* image = malloc(sizeof(bmp_image));
    image->header = *header;
    image->data = data;

    return image;
}

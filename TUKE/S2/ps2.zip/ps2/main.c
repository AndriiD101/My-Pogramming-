#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>
#include "k.h"

#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include "k.h"
#include "hof.h"
#include "ui.h"

int main(){
  struct game game = {
    .board = {
        {'A', 'B', 'C', 'D'},
        {'E', 'F', 'G', 'H'},
        {'I', 'J', 'K', 'A'},
        {'B', 'C', 'D', 'E'}
    },
    .score = 0
};

printf("is won: %d\n", is_game_won(game));
printf("is move possible: %d\n", is_move_possible(game));
add_random_tile(&game);
render(game);
}

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>
#include "k.h"

void add_random_tile(struct game *game){
    int row, col;
    // find random, but empty tile
    do{
        row = rand() % SIZE;
        col = rand() % SIZE;
    }while(game->board[row][col] != ' ');

    // place to the random position 'A' or 'B' tile
    if(rand() % 2 == 0){
        game->board[row][col] = 'A';
    }else{
        game->board[row][col] = 'B';
    }
}

bool is_game_won(const struct game game){
    for(int rows = 0; rows < SIZE; rows++){
        for(int cols = 0; cols < SIZE; cols++){
            if(game.board[rows][cols] == 'K') return true;
        }
    }
    return false;
}

bool is_move_possible(const struct game game){
    //horizontal checking
    // from left to right
    for(int rows = 0; rows < SIZE; rows++){
        for(int cols = 0; cols < SIZE-1; cols++){
            if(game.board[rows][cols] == game.board[rows][cols+1] || game.board[rows][cols+1]==' ') return true;
        }
    }
    //from right to left
    for(int rows = 0; rows < SIZE; rows++){
        for( int cols = SIZE-1; cols > 0; cols--){
            if(game.board[rows][cols]  == game.board[rows][cols-1] || game.board[rows][cols-1]==' ') return true;
        }
    }
    //vertical checking
    //from top to down
    for(int rows = 0; rows<SIZE-1; rows++){
        for(int cols = 0; cols<SIZE; cols++){
            if(game.board[rows][cols] == game.board[rows+1][cols] || game.board[rows+1][cols] == ' ') return true;
        }
    }
    //down to top
    for(int rows = SIZE-1; rows>0; rows--){
        for(int cols = 0; cols<SIZE; cols++){
            if(game.board[rows][cols] == game.board[rows-1][cols] || game.board[rows-1][cols] == ' ') return true;
        }
    }
    return false;
}